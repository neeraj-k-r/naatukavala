var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]__1we0oj0._.js")
R.c("server/chunks/[root-of-the-server]__0n5pkrw._.js")
R.c("server/chunks/frontend__next-internal_server_app_icon_png_route_actions_0_c1t_a.js")
R.m(16223)
module.exports=R.m(16223).exports
