globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/4UmtPMm6_RREtC22oLR1y/_buildManifest.js",
    "static/4UmtPMm6_RREtC22oLR1y/_ssgManifest.js",
    "static/4UmtPMm6_RREtC22oLR1y/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0lmiovqku8qx0.js",
    "static/chunks/24stzx4vdg_fv.js",
    "static/chunks/2y72kdrj6fr27.js",
    "static/chunks/2o5014m_pt-p5.js",
    "static/chunks/43bpop7y4hfhr.js",
    "static/chunks/turbopack-08f50b47zcxvh.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
