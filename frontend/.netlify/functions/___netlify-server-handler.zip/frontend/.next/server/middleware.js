var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1lm3gcs._.js")
R.c("server/chunks/[root-of-the-server]__09b1dnw._.js")
R.m(69043)
module.exports=R.m(69043).exports
